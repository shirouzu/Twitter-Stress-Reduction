/* ========================================================================
  Project  Name   : Twitter Stress Reduction
  Create          : 2016-11-25(Fri)
  Update          : 2021-09-10(Fri)
  Copyright       : H.Shirouzu
  License         : GNU General Public License version 3
  ======================================================================== */
"use strict";

let $ = function(id) { return document.getElementById(id); }
let tw_is_firefox = typeof InstallTrigger !== 'undefined';
let tw_is_mobile = window.matchMedia("(min-width: 500px)").matches ? false : true;
let tw_mob = { init:0 };
let tw_is_dark = null;
let tw_bg_col = "";
let tw_opt = {};

let tw_dbg = 0;

let tw_opt_count_key = "twf_cnt_";
let tw_purge_func = null;

let tw_purge_count = 0;
let tw_guard = 0;
let tw_guard_next = 0;
let tw_cur_url = "";

let tw_ignore_val   = 1;
let tw_maxname_len = 300;

let tw_badge_mode = { disable:1, reset:2, add:4 };

let twf_prefix = "twf_";
let twi_prefix = "twi_";
let tw_foldset_label = "✕";
let tw_foldunset_label = "〇";
let tw_menu_label = "☰";
let tw_height = "15px";
let tw_height_exp = "40px";
let tw_card_height = "20px";
let tw_pictlist_set = null;
let tw_is_recom_tab = false;

let tw_endchild_set = new Set();
let tw_endchild_check = 0;

let tw_keywd_list = [
  ["ja",                          "en",                           "zh-Hant",          "zh"],

  // おすすめタブ
  ["おすすめ",                    "For you",                      "為你推薦",         "为你推荐"],

  // コロナタブの MomentsJapan のアカウント名
  ["Twitter モーメント",          "Twitter Moments",              "○○",             "○○"],

  // home: complementary
  ["おすすめユーザー",            "Who to follow",                "跟隨誰",           "推荐关注" ],

  // home: complementary
  ["おすすめクリエーター",        "Recommend Creators",           "○○",             "○○" ],

  ["ユーザー",                    "People",                       "人物",             "用户" ],

  // メインメニュー → topics
  ["おすすめトピック",            "Suggested Topics",             "○○",             "○○"],
  ["おすすめのトピック",          "Topics to follow",             "○○",             "○○"],
  ["タイムラインにトピックも表示しましょう", "Expand your timeline with Topics", "○○",  "○○"],

  ["プレミアムにサブスクライブ",  "Subscribe to Premium",        "訂閱 Premium",     "Subscribe to Premium"],

  ["Grok",                        "Grok",                        "Grok",             "Grok"],

  // トピック画面の下（おすすめトピックが出ない場合は出ない）
  ["その他のトピック",            "More Topics",                 "○○",             "○○"],

  // home: "/explore/tabs/for-you"
  ["さらに表示",                  "Show more",                   "顯示更多",         "显示更多"],

  //
  ["すべて表示",                  "View all",                    "查看全部",         "查看全部"],

  // home: accessible-list-1
  ["タイムライン: ",              "Timeline: ",                  "時間軸：",         "时间线"],

  // メッセージタブ accessible-list-(0/12)
  ["タイムライン: メッセージ",    "Timeline: Messages",          "時間軸：訊息",     "时间线：私信"],

  // home: accessible-list-0
  ["タイムライン: トレンド",      "Timeline: Trending now",      "時間軸：流行趨勢", "时间线：当前趋势"],

  // リスト内
  ["タイムライン: リスト",        "Timeline: List",              "時間軸：列表",     "时间线：列表"],

  // リストタブ accessible-list
  ["タイムライン: 自分のリスト",  "Timeline: Your Lists",        "時間軸：你的列表", "时间线：你的列表"],

  // home: navigation筆頭 =home の上
  ["メインメニュー",              "Primary",                     "主要",             "主要"],

  // タイムラインに消えた状態で存在
  ["プロモーション",              "Promoted",                    "推廣",             "晋升"],

  // リストタブ: accessible-list-(x)
  ["新しいリストを見つける",      "Discover new Lists",          "○○",             "○○"],

  //
  ["自分のリスト",                "Your Lists",                  "你的列表",         "你的列表"],

  //
  ["関連性の高いアカウント",      "Relevant people",             "○○",             "○○"],

  // 認証マークを探す
  ["認証済みアカウント",          "Verified account",            "已認證的帳戶",     "认证账号"],

  // <img alt="画像"
  ["画像",                        "Image",                       "圖片",             "图像"],

  // 認証を受ける
  ["認証を受ける",                "Get Verified",                "獲得認證",         "获得认证"],

  // サイドバー
  ["コミュニティ",                "Communities",                 "社群",             "社群"],
  ["ブックマーク",                "Bookmarks",                   "書籤",             "书签"],
  ["プロフィール",                "Profile",                     "個人資料",         "个人资料"],
  ["認証済み",                    "Verified",                    "已認證",           "已认证"],
  ["プレミアム",                  "Premium",                     "Premium",          "Premium"],

  // ミュート表示
  ["表示する",                     "View",                       "查看",             "查看"],
  ["ミュートしているアカウントによるポストです。", "This Tweet is from an account you muted.", "此推文來自你設為靜音的帳戶。", "这条推文来自一个你已隐藏的账号。"],

  // センシティブ表示
  ["表示",                         "Show",                       "顯示",             "显示"],
  ["内容の警告",                   "Content warning",            "內容警告",         "内容警告"],

  null
];


let tw_svg_html = '<svg version="1.1" id="Logo" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 248 204" style="enable-background:new 0 0 248 204; height:28px; width:28px" xml:space="preserve"><style type="text/css">.st0{fill:#1D9BF0;}</style><g id="Logo_1_"><path id="white_background" class="st0" d="M221.95,51.29c0.15,2.17,0.15,4.34,0.15,6.53c0,66.73-50.8,143.69-143.69,143.69v-0.04 C50.97,201.51,24.1,193.65,1,178.83c3.99,0.48,8,0.72,12.02,0.73c22.74,0.02,44.83-7.61,62.72-21.66 c-21.61-0.41-40.56-14.5-47.18-35.07c7.57,1.46,15.37,1.16,22.8-0.87C27.8,117.2,10.85,96.5,10.85,72.46c0-0.22,0-0.43,0-0.64 c7.02,3.91,14.88,6.08,22.92,6.32C11.58,63.31,4.74,33.79,18.14,10.71c25.64,31.55,63.47,50.73,104.08,52.76 c-4.07-17.54,1.49-35.92,14.61-48.25c20.34-19.12,52.33-18.14,71.45,2.19c11.31-2.23,22.15-6.38,32.07-12.26 c-3.77,11.69-11.66,21.62-22.2,27.93c10.01-1.18,19.79-3.86,29-7.95C240.37,35.29,231.83,44.14,221.95,51.29z"/></g></svg>'

let tw_keywd_dicts = null;
let tw_keywd_langidx = null;
let tw_keywd_idx = 1;
let tw_self_lang = document.querySelector("html").getAttribute("lang");


function tw_msg(key, lang_spec) {
  if (!tw_keywd_dicts) {
    tw_keywd_dicts = [];
    tw_keywd_langidx = {};

    for (let lang_idx=0; lang_idx < tw_keywd_list[0].length; lang_idx++) {
      let cur_lang = tw_keywd_list[0][lang_idx];
      if (cur_lang == tw_self_lang) {
        tw_keywd_idx = lang_idx;
        console.debug("tw_msg: lang: %s", tw_self_lang);
      }
      tw_keywd_langidx[cur_lang] = lang_idx;
      let lang_dict = {}
      for (let keylist of tw_keywd_list) {
        if (keylist)
          lang_dict[keylist[0]] = keylist[lang_idx];
      }
      tw_keywd_dicts.push(lang_dict)
    }
  }

  let key_dict = tw_keywd_dicts[lang_spec ? tw_keywd_langidx[lang_spec] : tw_keywd_idx];

  if (key in key_dict)
    return key_dict[key];

  console.debug("tw_msg: %s not found", key);
  return key;
}

let tw_load_cb = null;

function tw_load(cb, need_dl) {
  tw_load_cb = cb;
  chrome.runtime.sendMessage({
    cmd: "load",
    need_dl: need_dl ? true : false
  });
}

function tw_set_twf(e, suffix) {
  e.setAttribute(tw_opt_count_key + suffix, tw_opt.tw_opt_count);
}

function tw_unset_twf(e, suffix) {
  e.setAttribute(tw_opt_count_key + suffix, 0);
}

function tw_gen_ign(suffix) {
  return ":not([" + tw_opt_count_key + suffix + "='" + tw_opt.tw_opt_count + "'])";
}

function tw_str2reg(key) {
  let spec_chars = "\\$.|?*+()[]{}";
  let rkey = "";

  for (let c of key) {
    if (spec_chars.indexOf(c) >= 0)
      rkey += "\\";
    rkey += c;
  }
  return rkey;
}

function tw_par_count(rkey) {
  let cnt = 0;
  let is_esc = false;
  let is_class = false;

  for (let c of rkey) {
    if (is_esc)
      is_esc = false;
    else if (c == '\\')
      is_esc = true;
    else if (is_class) {
      if (c == ']')
        is_class = false;
    } else if (c == '[')
      is_class = true;
    else if (c == '(')
      cnt++;
  }
  return cnt;
}

function tw_gen_regex(purge_trends) {
  let name_reg = {rkey:[], key:[], info:{0:"(none)"}, next_idx:0};
  let tag_reg  = {rkey:[], key:[], info:{0:"(none)"}, next_idx:0};

  for (let key of purge_trends.split("\n")) {
    key = key.trim();
    if (key.length <= 2)
      continue;

    let rkey = null;
    let is_name = false;
    let par_cnt = 1;

    if (key[0] == '?') {
      if (key[1] == '?')
        is_name = true;
      rkey = key.slice(is_name ? 2 : 1);
      try {
        new RegExp(rkey, "u"); // test compile
      }
      catch(e) {
        console.debug("tw_regex: invalid: %s", key);
        continue;
      }
      par_cnt += tw_par_count(rkey);
    }
    else
      rkey = tw_str2reg(key);

    let targ = is_name ? name_reg : tag_reg;

    targ.rkey.push(rkey);
    targ.key.push(key);
    targ.info[targ.next_idx] = key;
    targ.next_idx += par_cnt;
  }

  let ret = [];

  for (let reg of [name_reg, tag_reg]) {
    if (reg.rkey.length == 0)
      continue;

    ret.push({
      r:       new RegExp("(" + reg.rkey.join(")|(") + ")", "u"),
      key:     reg.key,
      info:    reg.info,
      is_name: reg == name_reg
    });
  }
  return ret;
}

function tw_match_idx(match_obj) {
  for (let i=1; i < match_obj.length; i++) {
    if (match_obj[i])
      return i-1;
  }
  return 0;
}

function tw_update_purge_func(purge_trends) {
  let match_funcs = [];

  for (let r of tw_gen_regex(purge_trends)) {
    match_funcs.push(function(ele, str, as_label) {
      //if (str.indexOf("ARM") >= 0)
      //  console.debug("tw_ arm");

      if ((as_label && !r.is_name) || str.length >= tw_maxname_len || str.length == 0 || ele.getAttribute("data-text"))
        return null;

      let m = r.r.exec(str);
      if (!m || !m[0])
        return null;

      let idx = tw_match_idx(m);
      // console.log("tw_update_purge_func key:", idx, r.info[idx], r, m);
      let targ = tw_get_trend_node(ele, false, r.is_name);
      if (!targ)
        return { node:null, key:r.info[idx], m:m[0], is_cardwrap:false, is_tweet: false };

      if (targ.is_tweet && !r.is_name)
        return null;
      return { node:targ.node, key:r.info[idx], m:m[0], is_cardwrap:targ.is_cardwrap, is_tweet: targ.is_tweet };
    });
  }
  return function(ele, str, as_label) {
    for (let func of match_funcs) {
      let ret = func(ele, str, as_label);
      if (ret)
        return ret;
    }
    return null;
  };
}

function tw_get_trend_node(ele, is_strict, is_name) {
  //tw_dbg = 1;
  if (tw_dbg)
    console.debug("tw_get_trend_node:", ele);

  if (is_strict) {
    if (!(ele = ele.parentNode) || ele.tagName != "SPAN")
      return null;
    if (!(ele = ele.parentNode) || ele.tagName != "DIV" || ele.getAttribute("dir") != "auto")
      return null;
  }

  let is_card = false;
  let targ = null;
  let targ_p0 = null;
  let targ_p1 = null;
  let targ_p2 = null;
  let targ_p3 = null;
  let is_tweet = false;
  let is_promo = tw_promo_svg_check(ele);

  for (let i=ele; i && i.parentNode; i=i.parentNode) {
    let test_id = i.getAttribute("data-testid");

    if (test_id == "primaryColumn" ||
      test_id == "videoPlayer" ||
      (!is_name && test_id == "tweet" && !is_promo))
      return null;

    if (test_id == "promotedIndicator")
      is_promo = true;

    if (test_id == "UserCell" && !targ) {
      targ = i;
      // is_tweet = true; // ?? にのみ引っ掛かるよう、偽装
    }

    if (!is_tweet && i.tagName == "ARTICLE" && !is_promo)
      is_tweet = true;

    if (!is_card && tw_radius_node(i)) {
      is_card = true;
      targ = i;
    }
    if (tw_is_entrylist_top(i)) {
      if (!targ && targ_p0 && !targ_p0.style.minHeight)
        targ = targ_p0;
      if (tw_dbg)
        console.debug("tw_get_trend_node: is_card=%s", targ, is_card);
      return { node:targ, is_cardwrap:is_card, is_tweet:is_tweet };
    }
    if (!targ) {
      targ_p0 = targ_p1;
      targ_p1 = targ_p2;
      targ_p2 = targ_p3;
      targ_p3 = i;
    }
  }
  return null;
}

function tw_promo_svg_check(ele) {
  if (!ele.parentNode || !ele.parentNode.parentNode)
    return false;

  let ppr = ele.parentNode.parentNode;
  if (ppr.childNodes.length != 2)
    return false;

  let node = ppr.firstChild;
  let tag = node ? node.tagName : null;
  if (!tag)
    return false;

  return tag.toUpperCase() == "SVG";
}

function tw_toobig_node(rc) {
  return rc.width * 1.3 >= window.innerWidth && rc.height * 1.3 >= window.innerHeight;
}

function tw_radius_node(node) {
  if (node.tagName != "DIV")
    return false;

  let style = getComputedStyle(node);
  let ret = parseInt(style.borderTopLeftRadius)  >= 10 &&
        parseInt(style.borderTopRightRadius) >= 10;

  return ret;
}

function tw_is_entrylist_top(node) {
  let label = node.getAttribute("aria-label");
  if (!label)
    return false;

  return (label.indexOf(tw_msg("タイムライン: ")) == 0 && label.indexOf(tw_msg("タイムライン: メッセージ"))
     || label == tw_msg("おすすめユーザー")
     || label == tw_msg("関連性の高いアカウント"));
}

function tw_set_badge(mode) {
  if (mode & tw_badge_mode.reset)
    tw_purge_count = 0;
  else if (mode & tw_badge_mode.add)
    tw_purge_count++;

  try {
    chrome.runtime.sendMessage({
      cmd: "set_badge",
      badgeText: tw_purge_count == 0 ? "" : tw_purge_count >= 99 ? "99+" : String(tw_purge_count),
      is_enable: (mode & tw_badge_mode.disable) ? false : true
    });
  }
  catch (e) {
    console.log("tw_set_badge can't send", e);
  }
}

function tw_set_hide_core(node, key, is_cardwrap, m) {
  tw_set_badge(tw_badge_mode.add);

  if (is_cardwrap) {
    node.style.height = tw_card_height;
    node.style.minHeight = tw_card_height;
    for (let e of node.childNodes) {
      e.style.height = tw_card_height;
      e.style.opacity = 0;
    }
  }
  else
    node.style.display = "none";

  console.log("tw_set_hide:", key, {detail:{intxt: node.innerText, node: node}}, m);
}

function tw_set_hide(info) {
  let node = info.node;
  if (node.style.display == "none" || node.style.overflow == "hidden" || node.style.height == tw_card_height)
    return;

  tw_set_hide_core(node, info.key, info.is_cardwrap, info.m)
}

function tw_deep_child(node, n) {
  for (let i=0; i < n && node; i++)
    node = node.firstChild;

  return node;
}

function tw_get_text(e) {
  if (!e || !e.firstChild)
    return null;
  return e.firstChild.nodeValue;
}

function tw_is_direct_self_tweet(ret) {
  if (!ret.is_tweet || ret.is_cardwrap)
    return false;

  let url = tw_get_tweet_url(ret.node, false);
  return url && tw_cur_url.indexOf(url) == 0;
}

function tw_promo_check() {
  let err_cnt = 0;
  let ign_key = "promo";
  let ign_str = tw_gen_ign(ign_key);
  let is_direct = tw_cur_url.indexOf("/status/") > 0;

  if (tw_opt.tw_msgtab) {
    for (let e of document.querySelectorAll("div[data-testid='DMDrawer']" + ign_str)) {
      try {
        tw_set_twf(e, ign_key);
        if (e.style.display != "none") {
          e.style.display = "none";
          console.log("tw_ to hide dm drawer");
        }
      }
      catch(e) {
        console.log("tw_err", e);
        if (err_cnt++ > 10)
          return;
      }
    }
  }

  for (let e of document.querySelectorAll("span" + ign_str + ",a[dir='ltr']" + ign_str)) {
    try {
      tw_set_twf(e, ign_key);

      let intxt = tw_get_text(e);
      if (!intxt)
        continue;

      if (tw_opt.tw_promo_del) {
        if (intxt == tw_msg("プロモーション")) {
          let p = tw_get_trend_node(e, false, true);
          if (p) {
            let n = p.node;
            if (n.style.display != "none") {
              n.style.display = "none";
              for (let sn of [n.parentNode.previousSibling, n.parentNode.nextSibling])
                if (sn && !sn.innerText)
                  sn.firstChild.style.display = "none";
              console.log("tw_promo_check", n.innerText.slice(0, 30).replace(/\n/g, " "));
            }
            continue;
          }
        }
      }
      if (tw_opt.tw_purge_trends) {
        let ret = tw_purge_func(e, intxt, false);
        if (ret && ret.node) {
          if (!is_direct || !tw_opt.tw_direct_pass || !tw_is_direct_self_tweet(ret))
            tw_set_hide(ret);
        }
      }
    }
    catch(e) {
      console.log("tw_err", e);
      if (err_cnt++ > 10)
        return;
    }
  }

  for (let e of document.querySelectorAll("div[aria-label]" + ign_str + ",img[alt]" + ign_str)) {
    try {
      tw_set_twf(e, ign_key);

      if (!tw_opt.tw_purge_trends)
        continue;
      let is_img = e.tagName == "IMG";
      let val = e.getAttribute(is_img ? "alt" : "aria-label");
      if (!val || is_img && val == tw_msg("画像"))
        continue;

      if (val && tw_opt.tw_purge_trends) {
        let ret = tw_purge_func(e, val, true);
        if (ret && ret.node) {
          if (!is_direct || !tw_opt.tw_direct_pass || !tw_is_direct_self_tweet(ret))
            tw_set_hide(ret);
        }
      }
    }
    catch(e) {
      console.log("tw_lable_err", e);
      if (err_cnt++ > 10)
        return;
    }
  }
}

function tw_fold_footer(e) {
  let v = e.querySelector("button[aria-label][data-testid*='like']");
  if (!v) {
    console.debug("tw_fold_footer: not found", e);
    return null;
  }
  return v.parentNode.parentNode;
}

function tw_is_set(gallery) {
  return ((gallery.style.height == tw_height || gallery.style.height == tw_height_exp) && gallery.style.overflow == "hidden") ? true : false;
}

function tw_fold_act_core(gallery, is_explore, is_set) {
  if (!gallery)
    return;
  gallery.style.height = is_set ? (is_explore ? tw_height_exp : tw_height) : "";
  if (is_explore) {
    let n1 = gallery.childNodes[1];
    let n2 = n1 && n1.firstChild;
    let n3 = n2 && n2.childNodes[1];
    if (n3) {
      n1.style.paddingTop = is_set ? "40px" : null;
      n1.style.backgroundColor = is_set ? (tw_is_dark ? tw_bg_col : "white") : null;
      n3.style.fontSize = is_set ? "105%" : null;
      n3.style.color = is_set ? (tw_is_dark ? "white" : "black") : null;

      let n4 = n2 && n2.childNodes[2];
      if (n4)
        n4.style.display = is_set ? "none" : "";
    }
  }
  gallery.style.overflow = is_set ? "hidden" : "";
  return false;
}

function tw_fold_act(e, btn, gallery, is_explore, is_set) {
  tw_fold_act_core(gallery, is_explore, is_set);
  if (btn) {
    btn.innerText = is_set ? tw_foldset_label : tw_foldunset_label;
    if (is_explore) {
      btn.style.cursor = is_set ? "zoom-in" : "zoom-out";
      btn.style.paddingTop = is_set ? "13px" : "0px";
    }
  }
}

function tw_fold_key(twid) {
  if (!twid) return "";
  return  twf_prefix + twid;
}

function tw_fold_img_key(src) {
  if (!src) return "";
  return  twi_prefix + src;
}

function tw_fold_getval(src, tw_id) {
  let src_key = tw_fold_img_key(get_image_id(src));
  let val = localStorage.getItem(src_key);
  if (!val)
    val = 0;

  return val;
}

function tw_fold_setval(src, tw_id, val) {
  let src_key = tw_fold_img_key(get_image_id(src));

  if (val)
    localStorage.setItem(src_key, val);
  else
    localStorage.removeItem(src_key);

  return true;
}

function tw_fold_click(e, btn, gallery) {
  let val = tw_fold_getval(btn.src, btn.tw_id);

  if (!btn.is_explore && tw_opt.tw_image_rev || btn.is_explore && tw_opt.tw_explore_rev)
    val = (val == 0 || val == 1) ? 2 : 0;
  else
    val = (val == 0 || val == 2) ? 1 : 0;

  tw_fold_setval(btn.src, btn.tw_id, val);

  tw_fold_act(e, btn, gallery, btn.is_explore, val);

  setTimeout(function() { tw_fold_check(true); }, 0);

  return false;
}

function tw_endchild_mutation_core() {
  // console.log("tw_endchild_mutation_core start", tw_endchild_set.size);

  if (!tw_opt.tw_qt || !tw_opt.tw_fold)
    return;

  tw_endchild_check = 2;
  while (tw_endchild_set.size > 0) {
    let clist = Array.from(tw_endchild_set.keys());
    tw_endchild_set.clear();

    for (let c of clist) {
      let parent = c.parentNode;
      if (parent && parent.childNodes.length > 2) {
        if (c.mo) {
          c.mo.disconnect();
          c.mo = null;
        }
        let c1 = parent.childNodes[parent.childNodes.length - 1];
        let c2 = parent.childNodes[parent.childNodes.length - 2];
        if (c2.getAttribute("tw_qt_id")) {
          parent.removeChild(c2);
          parent.appendChild(c2);
          // console.log("tw_endchild_mutation_core swap");
        }
        // else console.log("tw_endchild_mutation_core normal");
      }
    }
  }
  // console.log("tw_endchild_mutation_core end");

  tw_endchild_check = 0;
}


function tw_endchild_mutation(c) {
  if (!tw_opt.tw_qt || !tw_opt.tw_fold)
    return;

  let mo = new MutationObserver((mutations, _mo) => {
    if (mutations.length <= 0 && mutations[0].addedNodes.length <= 0)
      return;
    c.mo = null; // _mo;
    tw_endchild_set.add(c);

    if (tw_endchild_check == 0) {
      tw_endchild_check = 1;
      setTimeout(function() { tw_endchild_mutation_core(); }, 0);
    }
  });
  mo.observe(c.parentNode, {childList:true, subtree: false});
}

function tw_mkfold(menu, parent, gallery, tw_id, src, is_inner, is_set, is_explore) {
  let c = document.createElement("div");
  c.innerText = is_set ? tw_foldset_label : tw_foldunset_label;
  c.tw_id = tw_id;
  c.setAttribute("tw_fold_id", tw_id);
  c.src = src;
  c.gallery = gallery;
  c.is_explore = is_explore;

  if (is_explore) {
    c.className = "css-1dbjc4n r-1mlwlqe r-18u37iz r-18kxxzh r-1h0z5md";
    c.style = "height:40px; width:15px; position:absolute; top:0px; right:1px; font-size:60%; text-color:rgba(10,10,10,0.3); text-shadow:2px 2px 0 rgba(220,220,220,.5); background-color: transparent; padding:5px; ";
    c.style.cursor     = is_set ? "zoom-in" : "zoom-out";
    c.style.paddingTop = is_set ? "14px" : "0px";
  }
  else {
    let style = "padding:10px; border-radius: 15px; color:grey; cursor:pointer;";

    if (!tw_is_mobile) {
      if (is_inner) {
        let is_timeline = parseInt(getComputedStyle(menu.lastChild).height) <= 42;
        style += "top:2px; right:" + (is_timeline ? "-15px" : "0px");
      }
      else
        style += "top:0px; right:-60px;";
    }

    c.className = menu.lastChild.className;
    c.style = style;

    if (!tw_is_mobile) {
      c.onmouseover=function() { c.style.backgroundColor= tw_is_dark ? '#123' : '#def'; };
      c.onmouseout =function() { c.style.backgroundColor = "transparent"; };
    }
  }
  c.onclick = function(e) {
    tw_fold_click(parent, c, gallery);
    e.stopPropagation();
    return false;
  }
  menu.appendChild(c);
  tw_endchild_mutation(c);

  return c;
}

function tw_mkqt(menu, targ_url) {
  let c = document.createElement("div");
  c.innerText = "R";
  c.setAttribute("tw_qt_id", 1);

  let style = "padding:12px; border-radius: 15px; color:grey; cursor:pointer;";

  if (!tw_is_mobile) {
    style += "top:0px; right:-10px;";
  }

  c.className = menu.lastChild.className;
  c.style = style;

  if (!tw_is_mobile) {
    c.onmouseover=function() { c.style.backgroundColor= tw_is_dark ? '#123' : '#def'; };
    c.onmouseout =function() { c.style.backgroundColor = "transparent"; };
  }

  c.onclick = function(e) {
    let url = targ_url + "/quotes";
    if (e.ctrlKey)
      window.open(url, "_blank");
    else
      location.href = url;
    return false;
  }
  menu.appendChild(c);
  tw_endchild_mutation(c);
}

function tw_get_tweet_url(node, with_label) {
  let alist = node.querySelectorAll(with_label ? "a[aria-label][role='link']" : "a[role='link']");
  for (let a of alist) {
    let idx = a.href.indexOf("/status/");
    if (idx < 0)
      continue;
    let url = a.href;
    if (url.endsWith("/history")) // 編集ツイート対策
      url = url.slice(0, -8);
    if (with_label || url.slice(idx + 8).indexOf("/") < 0) // /status/xxx/photo等で無い
      return url;
  }
  return null;
}

function get_tweet_info(ele, is_promo, img) {
  let ar  = null;
  let tw_id  = null;
  let list_header = null;
  let inner = false;

  let dbg = 0;
  if (dbg) console.debug("tw_get_tweet_info1:", ele, is_promo, img);

  for (let i=ele; i && i.parentNode; i=i.parentNode) {
    if (ar) {
      if (i.getAttribute("data-testid") == "cellInnerDiv") {
        return {tw_id:tw_id, tw:i, inner:inner, alt:null};
      }
    } else if (i.tagName == 'ARTICLE') {
      ar = i;
      if (is_promo) continue;

      let url = tw_get_tweet_url(ar, true);
      let targ_url = url ? url : tw_cur_url;
      inner = true;

      if (!url) {
        let da_list = ar.querySelectorAll("div[data-testid]");
        for (let da of da_list) {
          if ((url = tw_get_tweet_url(da, true))) {
            targ_url = url;
            inner = false;
            break;
          }
        }
      }
      let idx = targ_url.indexOf("/status/");
      if (idx > 0) {
        tw_id = targ_url.slice(idx + 8);
      }
      if (!tw_id) {
        if (dbg) console.debug("tw_none: ", ar, da, targ_url);
        return null;
      }
    } else if (list_header) {
      if (i.getAttribute("data-testid") == "cellInnerDiv") {
        return {tw_id:0, tw:i, inner:inner, alt:null}; // list header
      }
    } else if (img && img.clientWidth == 598 && img.clientHeight == 199) {
      list_header = i;
    }
  }
  if (!ar && list_header) {
    return {tw_id:0, tw:list_header, inner:null, alt:null};
  }
  return null;
}

function get_gallery_node(img, is_video) {
  let height = img.clientHeight;
  let candidate = null;

  for (let n=img; n && n.parentNode; n=n.parentNode) {
    if (tw_is_set(n))
      return n;

    let cs = window.getComputedStyle(n);
    let rad = cs.borderBottomLeftRadius;
    if (rad && rad.charAt(0) != "0")
      return n;

    if (!candidate && (n.parentNode.clientHeight - height) > 50)
      candidate = n;
  }
  return candidate;
}

function get_explore_node(img) {
  for (let n=img; n && n.parentNode; n=n.parentNode)
    if (n.getAttribute("data-testid") == "eventHero")
      return n;
  return null;
}

let img_src_list = ["/media/", "/card_img/", "/semantic_core_img/", "/pu/img/", "/ad_img/", "/tweet_video/", ""];

function get_image_id(node_src) {
  for (let img_src of img_src_list) {
    let idx = img_src ? node_src.indexOf(img_src) : node_src.lastIndexOf("/");
    if (idx >= 0) {
      let src = node_src.slice(img_src.length + idx)
      let last_idx = src.indexOf("?");

      if (last_idx < 0)
        last_idx = src.indexOf("/")

      return (last_idx > 0) ? src.slice(0, last_idx) : src;
    }
  }

  return 0;
}

function get_image_info(node, is_video) {
  let dbg = 0;
  if (dbg)
    console.debug("tw_get_image_info:", node, is_video);

  let is_explore = tw_cur_url.indexOf("/explore") >= 0 ? true : false;

  let rc = node.getBoundingClientRect();
  if (rc.width < (is_explore ? 300 : 130))
    return null;

  if (!is_video) {
    let found = false;
    for (let img_src of img_src_list) {
      if (node.src.indexOf(img_src) >= 0) {
        found = true;
        break;
      }
    }
    if (!found) {
      if (dbg) console.debug("tw_none 1");
      return null;
    }
  }

  let gal_node = is_explore ? get_explore_node(node) : get_gallery_node(node, is_video);
  if (is_explore && !gal_node) {
    gal_node = get_gallery_node(node, is_video);
    is_explore = false;
  }

  if (!gal_node) {
    if (dbg) console.debug("tw_none 2");
    return null;
  }

  if (is_explore) {
    let tw_id = get_image_id(node.src);
    if (!tw_id)
      return null;
    return {tw_id:tw_id, tw:gal_node, gallery:gal_node, inner:false, is_explore:is_explore, src:node.src};
  }

  let gal_node2 = get_gallery_node(node, is_video);

  let tw_info = get_tweet_info(gal_node, false, node);
  if (!tw_info || !tw_info.tw_id) {
    if (tw_cur_url.indexOf("/lists/") >= 0) {
      let rc = node.getBoundingClientRect();
      if (tw_info && rc.height > 120 && rc.width > 120)
        gal_node.style.height = "10px";
      else if (dbg)
        console.debug("tw_none 3", tw_info);
    }
    return null;
  }
//  if (gal_node.className == "css-1dbjc4n r-1adg3ll r-1udh08x")
//    gal_node = gal_node.parentNode; // 一つ親にしないと真ん中で fold される場合

  tw_info.gallery = gal_node;
  tw_info.is_explore = is_explore;
  tw_info.src = is_video && node.poster ? node.poster : node.src;

  return tw_info;
}

function tw_get_imgnode_list(need_unset_check) {
  let ans = [];
  let gal_dict = {};
  let ign_key = need_unset_check ? "" : "imgnode";
  let ign_str = need_unset_check ? "" : tw_gen_ign(ign_key);

  for (let e of document.querySelectorAll("img" + ign_str + ",video" + ign_str)) {
    if (ign_key)
      tw_set_twf(e, ign_key);
    let is_video = e.tagName == "VIDEO";

    if (!is_video && e.src.indexOf("/ext_tw_video_thumb/") >= 0)
      continue;

    let info = get_image_info(e, is_video);

    if (info && (!info.tw_id || !gal_dict[info.tw_id])) {
      if (info.tw_id)
        gal_dict[info.tw_id] = 1;
      ans.push(info);
    }
  }
  //console.debug("tw_get_imgnode_list: ", ans);

  return ans;
}

function tw_get_qtnode_list() {
  let ign_key = "qtnode";
  let ign_str = tw_gen_ign(ign_key);
  let qlist = [];

  let alist = document.querySelectorAll("article[data-testid='tweet']" + ign_str);
  for (let ar of alist) {
    if (ign_key)
      tw_set_twf(ar, ign_key);

    let url = tw_get_tweet_url(ar, true);
    if (url) {
      let footer = tw_fold_footer(ar);
      if (footer)
        qlist.push({footer:footer, targ_url:url});
    }
  }
  return qlist;
}

function tw_fold_check(need_unset_check) {
  if (!tw_opt.tw_fold)
    return;

  let ilist = tw_get_imgnode_list(need_unset_check);

  for (let info of ilist) {
    let btn = null;
    let val = tw_fold_getval(info.src, info.tw_id, info.is_explore);
    let is_set;

    if (!info.is_explore && tw_opt.tw_image_rev || info.is_explore && tw_opt.tw_explore_rev)
      is_set = (val == 0 || val == 1);
    else
      is_set = (val == 1);

    if (need_unset_check) {
      let q = 'div[tw_fold_id="' + info.tw_id + '"]';
      btn = document.querySelector(q);
    }
    if (is_set || need_unset_check)
      tw_fold_act(info.tw, btn, info.gallery, info.is_explore, is_set);

    let f = info.is_explore ? info.tw : tw_fold_footer(info.tw);
    if (!f || !f.lastChild) {
      // console.debug("tw_fold_check cont")
      continue;
    }

    if (f.getAttribute("tw_fold_btn") == 1) {
      let old = f.querySelector('div[tw_fold_id]');
      if (old) {
        old.parentNode.removeChild(old);
        // console.debug("tw_fold_check remove")
      }
    }
    else f.setAttribute("tw_fold_btn", 1);
    // console.debug("tw_fold_check make")

    tw_mkfold(f, info.tw, info.gallery, info.tw_id, info.src, info.inner, is_set, info.is_explore);
  }
}



function tw_qt_check() {
  if (!tw_opt.tw_qt_ex) {
    let re = /\/(status|i\/lists)\/[0-9]+(\/|$)/;
    if (!re.exec(location.href))
      return;
  }

  for (let qt of tw_get_qtnode_list())
    tw_mkqt(qt.footer, qt.targ_url);
}

function tw_movement() {
  let ign_key = "move";
  let ign_str = tw_gen_ign(ign_key);
  let node = document.querySelector(
      "div[aria-label='" + tw_msg("タイムライン: トレンド") + "']" + ign_str);

  if (node) {
    tw_set_twf(node, ign_key);

    if (node.style.display != "none") {
      node.style.display = "none";
      //console.log("tw_filter: hide movement");
    }
  }
}

function tw_premium() {
  let ign_key = "premium";
  let ign_str = tw_gen_ign(ign_key);
  let node = document.querySelector(
      "aside[aria-label='" + tw_msg("プレミアムにサブスクライブ") + "']" + ign_str);

  if (node) {
    tw_set_twf(node, ign_key);

    if (node.parentNode.style.display != "none") {
      node.parentNode.style.display = "none";
        console.log("tw_filter: hide premium");
    }
  }
}

function tw_recommend() {
  let ign_key = "recom";
  let ign_str = tw_gen_ign(ign_key);
  let node = document.querySelector(
      "aside[aria-label='" + tw_msg("おすすめユーザー") + "']" + ign_str);

  if (node) {
    tw_set_twf(node, ign_key);

    if (node.style.display != "none") {
      let parent_rc = node.parentNode.getBoundingClientRect();
      if (!tw_toobig_node(parent_rc))
        node.parentNode.style.display = "none";

      node.style.display = "none";
      //console.log("tw_filter: hide recommed");
    }
  }
}

function tw_recommend_timeline() {
  let ign_key = "recomTL";
  let ign_str = tw_gen_ign(ign_key);
  let top_nodes = document.body.querySelectorAll(
            "div[aria-label^='" + tw_msg("タイムライン: ") + "']");

  for (let top_node of top_nodes) {
    for (let key_node of top_node.querySelectorAll(":scope > div > div > div > div > div > h2[role='heading'] > div > span" + ign_str)) {
      tw_set_twf(key_node, ign_key);
      let kind = key_node.innerText;
      let node = key_node.parentNode.parentNode;

      if (tw_opt.tw_recommend && (
          kind == tw_msg("おすすめユーザー") ||
          kind == tw_msg("おすすめクリエーター") ||
          kind == tw_msg("おすすめユーザー", "en") ||
          kind == tw_msg("ユーザー"))
         || tw_opt.tw_recom_topic &&
          (
          kind == tw_msg("おすすめトピック") ||
          kind == tw_msg("おすすめのトピック") ||
          kind == tw_msg("タイムラインにトピックも表示しましょう")
          )
      ) {
        //console.log("tw_recom inner find", key_node);
      }
      else {
        // console.log("tw_recom not inner", key_node);
        continue;
      }

      let targ = node.parentNode;
      if (targ) targ = targ.parentNode;
      if (targ) targ = targ.parentNode;
      if (targ) targ = targ.parentNode;
      if (!targ || !targ.previousSibling || !targ.nextSibling) {
        if (targ) { // 未完了なだけの場合
          tw_unset_twf(key_node, ign_key);
          // console.log("tw_recom incomp", key_node);
        }
        continue;
      }
      let set_hide = targ.previousSibling.innerText ? [targ] : [targ.previousSibling, targ];
      let find_end = false;
      for (let n=targ.nextSibling; n; n=n.nextSibling) {
        let txt = n.innerText;
        set_hide.push(n);
        if (set_hide.length >= 10 || find_end)
          break;

        if (txt == tw_msg("さらに表示") ||
            txt == tw_msg("さらに表示", "en") ||
            txt == tw_msg("すべて表示") ||
            txt == tw_msg("その他のトピック"))
          find_end = true;
      }
      if (find_end) {
        for (let n of set_hide)
          n.firstChild.style.display = "none";
        console.log("tw_hide_topic/user_in_TL: %s", kind);
      }
      else {
        tw_unset_twf(key_node, ign_key);
        // console.log("tw_recom incomp2", key_node);
      }
    }
  }
}

function tw_recom_topic() {
  let ign_key = "topic";
  let ign_str = tw_gen_ign(ign_key);
  let nodes = document.querySelectorAll("section[aria-labelledby*='accessible-list']" + ign_str);

  for (let node of nodes) {
    tw_set_twf(node, ign_key);

    let rc = node.getBoundingClientRect();
    if (rc.left < window.innerWidth / 2)
      continue;
    let label = node.childNodes.length >= 2 ? node.childNodes[1].getAttribute("aria-label") : null;
    if (label == tw_msg("タイムライン: メッセージ"))
      continue;

    let span = node.querySelector("span");
    if (span && span.firstChild) {
      let intxt = tw_get_text(span);
      if (intxt != tw_msg("おすすめトピック"))
        continue;
    }
    if (!node || node.style.display == "none")
      continue;

    node.style.display = "none";
    //console.log("tw_filter: hide recommed topic");
    break;
  }
}

function tw_sidebar() {
  let ign_key = "sidebar";
  let ign_str = tw_gen_ign(ign_key);

  for (let key of ["コミュニティ", "ブックマーク", "プロフィール", "認証済み", "プレミアム", "Grok"]) {
    let nodes = document.body.querySelectorAll("a[aria-label='" + tw_msg(key) + "']" + ign_str);

    for (let node of nodes) {
      tw_set_twf(node, ign_key);
      node.style.display = "none";
      console.log("tw_filter: hide tw_sidebar(%s)", key);
    }
  }
}

function tw_quotert() {
  let ign_key = "quotert";
  let ign_str = tw_gen_ign(ign_key);

  let nodes = document.body.querySelectorAll("div[tabindex][role='link']" + ign_str);

  for (let n of nodes) {
    tw_set_twf(n, ign_key);

    let info = get_tweet_info(n);
    if (info && info.tw) {
      tw_set_hide_core(info.tw, ign_key, false, false)
      console.log("tw_filter: hide tw_quotert", info.tw);
    }
  }
}

function tw_muteshow() {
  let ign_key = "muteshow";
  let ign_str = tw_gen_ign(ign_key);

  let nodes = document.body.querySelectorAll("div[tabindex][role='button']" + ign_str);

  for (let n of nodes) {
    tw_set_twf(n, ign_key);
    if (n.innerText == tw_msg("表示する")) {
      if (n.parentNode && n.parentNode.parentNode &&
        n.parentNode.parentNode.firstChild.innerText == tw_msg("ミュートしているアカウントによるポストです。")) {
        setTimeout(function() { tw_prop(n); n.click(); }, 100); // 暫定対処
        console.log("tw_filter: tw_muteshow", n);
      }
    }
  }
}

function tw_sensitive_show() {
  let ign_key = "sensitive_show";
  let ign_str = tw_gen_ign(ign_key);

  let nodes = document.body.querySelectorAll("div[tabindex][role='button']" + ign_str);

  for (let n of nodes) {
    tw_set_twf(n, ign_key);
    if (n.innerText == tw_msg("表示")) {
      if (n.parentNode && n.parentNode.parentNode &&
        n.parentNode.parentNode.firstChild.innerText.indexOf(tw_msg("内容の警告")) == 0) {
        n.click();
        console.log("tw_filter: tw_sensitive_show", n);
      }
    }
  }
}

function tw_pivothide() {
  let ign_key = "pivot";
  let ign_str = tw_gen_ign(ign_key);

  let nodes = document.body.querySelectorAll("div[data-testid='birdwatch-pivot']" + ign_str);

  for (let n of nodes) {
    tw_set_twf(n, ign_key);
    if (n.parentNode) {
      if (n.parentNode.getAttribute("role")) {
        tw_set_hide_core(n, ign_key, false, false);
        if (n.nextSibling)
          n.nextSibling.style.display = "none";
      }
      else
        tw_set_hide_core(n.parentNode, ign_key, false, false);
    }
  }
}

function tw_explore_verify() {
  let top_node = document.body;

  if (tw_cur_url.indexOf("twitter.com/explore") < 0 && tw_cur_url.indexOf("x.com/explore") < 0) {
    top_node = top_node.querySelector(
            "div[aria-label='" + tw_msg("タイムライン: トレンド") + "']");
    if (!top_node)
      return;
  }

//  let url_kinds = ["for-you", "/explore/tabs/trending", "/explore/tabs/news_unified", "explore/tabs/sports_unified", "/explore/tabs/entertainment_unified"];
//  for (let kind of url_kinds) {
//    if (tw_cur_url.indexOf("/explore/tabs/" + kind) > 0) {
//      is_explorer = true;
//      break;
//    }
//  }
  let err_cnt = 0;
  let ign_key = "verify";
  let ign_str = tw_gen_ign(ign_key);

  for (let e of top_node.querySelectorAll(
    "svg[aria-label='" + tw_msg("認証済みアカウント") + "']" + ign_str)) {
    try {
      tw_set_twf(e, ign_key);
      let ret = tw_get_trend_node(e, false, true);
      if (!ret || !ret.node || ret.is_tweet)
        continue;

      let icon = ret.node.querySelector("div[role='presentation']");
      if (!icon || icon.clientHeight >= 25)
        continue;
      if (ret.is_cardwrap) {
        let par = tw_get_trend_node(ret.node.parentNode, false, true);
        if (par && par.is_tweet)
          continue;
      }

      let name = "";
      let name_node = e.parentNode.parentNode.querySelector("span");
      if (name_node && name_node.firstChild) {
        let intxt = tw_get_text(name_node);
        if (intxt)
          name = intxt;
      }
      if (name == tw_msg("Twitter モーメント"))
        continue;
      ret.key = e.getAttribute("aria-label");
      ret.m = name;

      tw_set_hide(ret);
    }
    catch(e) {
      console.log("tw_lable_err", e);
      if (err_cnt++ > 10)
        return;
    }
  }
}

function tw_is_pictradius(n) {
  let e = n;
  for (let i=0; i < 10 && e && e.tagName != "ARTICLE"; i++) {
    let style = getComputedStyle(e);
    if (parseInt(style.borderTopLeftRadius) >= 10)
      return true;
    e = e.parentNode;
  }
  return false;
}

function tw_pictlist() {
  let idx = tw_cur_url.indexOf("/lists/");
  if (idx < 0) return;
  let id = tw_cur_url.slice(idx + 7);
  let list_num = Number(id);
  if (isNaN(list_num) || !tw_pictlist_set.has(list_num)) return;

  let err_cnt = 0;
  let ign_key = "pict";
  let ign_str = tw_gen_ign(ign_key);

  let top = document.querySelector("div[aria-label='" + tw_msg("タイムライン: リスト") + "']");
  if (!top || !top.firstChild) return;
  top = top.firstChild;

//  console.log("tw_pictlist: ", list_num);
  let info = {node:null, is_cardwrap:false, m:"", key:""};

  for (let n of top.querySelectorAll(":scope > div > div" + ign_str)) {
    if (n == top.parentNode.firstChild) continue;
    let url = tw_get_tweet_url(n);
    if (!url) continue;

    let photo = url + "/photo/";

    try {
      let d = n.querySelector("a[href*='/photo/']");
      if (d) {
        let img = d.querySelector("img");
        if (!img)
          continue; // constructing...

        if (tw_is_pictradius(d)) {
          tw_set_twf(n, ign_key); 
          continue;
        }
      }
      else {
        let v = n.querySelector("div[data-testid='videoPlayer'],div[role='progressbar']");
        if (v) {
          tw_set_twf(n, ign_key); 
          continue;
        }
      }
      tw_set_twf(n, ign_key); 
      info.node = n;
      console.debug("tw_pict: ", n.innerText.slice(0, 80).replace(/\n/g, " "));
      tw_set_hide(info);
    }
    catch(e) {
      console.log("tw_lable_err", e);
      if (err_cnt++ > 10)
        return;
    }
  }
}

function tw_xlogo_check() {
  let ign_key = "tw_xlogo";
  let ign_str = tw_gen_ign(ign_key);
  let node = document.querySelector("a[aria-label='X'][role='link']" + ign_str);

  if (!node || !tw_deep_child(node, 2)) return;
  tw_set_twf(node, ign_key);

  node.firstChild.innerHTML = tw_svg_html;
}

function tw_favicon_check() {
  let fav = document.querySelector("link[rel='shortcut icon']");
  if (fav) {
      let ico_url = fav.href;
      //console.log("tw_xlogo_check:", fav, ico_url);
      let new_url = "//abs.twimg.com/favicons/twitter" + (ico_url.indexOf("pip") > 0 ? "-pip": "") + ".ico";
      if (new_url != ico_url)
        fav.href = new_url;
  }
}

function tw_blueinv() {
  let ign_key = "blueinv";
  let ign_str = tw_gen_ign(ign_key);
  let node = document.querySelector(
      "aside[aria-label='" + tw_msg("認証を受ける") + "']" + ign_str);

  if (node) {
    tw_set_twf(node, ign_key);

    if (node.style.display != "none") {
      let parent_rc = node.parentNode.getBoundingClientRect();
      if (!tw_toobig_node(parent_rc))
        node.parentNode.style.display = "none";

      node.style.display = "none";
      //console.log("tw_filter: hide recommed");
    }
  }
}

function tw_is_ja(s) { // ひらがな・カタカナ・常用漢字（の多く）
  return /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF\u3400-\u4DBF]/.test(s);
}

function tw_recom_img_hide() {
  let ign_key = "video_node";
  let ign_str = tw_gen_ign(ign_key);

  for (let e of document.querySelectorAll("img" + ign_str + ",video" + ign_str)) {
    if (ign_key)
      tw_set_twf(e, ign_key);

    let rc = e.getBoundingClientRect();
    if (rc.width < 100)
      continue;

    let info = get_tweet_info(e, false);
    if (!info || !info.tw)
      continue;

    let txtnode = info.tw.querySelector("div[data-testid='tweetText']");
    if (txtnode && tw_self_lang == "ja" && tw_is_ja(txtnode.innerText))
      continue;

    if (info.tw.style.display != "none") {
      info.tw.style.display = "none";
      console.log("tw_recom_img_hide: ", txtnode && txtnode.innerText, info.tw);
    }
  }
}

function tw_filter_core() {
  while (1) {
    tw_guard_next = 0;
    if (tw_opt.tw_enabled) {
      tw_mob_stat();

      // console.log("tw_filter_core loop");
      if (tw_opt.tw_promo_del || tw_opt.tw_purge_trends)
        tw_promo_check();

      if (tw_pictlist_set)
        tw_pictlist();

      if (tw_opt.tw_movement) {
        tw_movement();
        tw_premium();
      }

      if (tw_opt.tw_recommend)
        tw_recommend();

      if (tw_opt.tw_blueinv)
        tw_blueinv();

      if (tw_opt.tw_recom_topic)
        tw_recom_topic();

      if (tw_opt.tw_recommend || tw_opt.tw_recom_topic)
        tw_recommend_timeline();

      if (tw_opt.tw_explore_verify)
        tw_explore_verify();

      if (tw_opt.tw_sidebar)
        tw_sidebar();

      if (tw_opt.tw_quotert &&
          tw_cur_url.indexOf("/retweets/with_comments") < 0 && tw_cur_url.indexOf("/status/") < 0)
        tw_quotert();

      if (tw_opt.tw_muteshow)
        tw_muteshow();

      if (tw_opt.tw_sensitive_show)
        tw_sensitive_show();

      if (tw_opt.tw_pivot)
        tw_pivothide();

      if (tw_opt.tw_qt)
        tw_qt_check();

      if (tw_opt.tw_fold)
        tw_fold_check(false);

      if (tw_is_recom_tab && tw_opt.tw_recom_img)
        tw_recom_img_hide();

      if (tw_opt.tw_xlogo) {
        tw_xlogo_check();
        tw_favicon_check();
      }
    }
    if (tw_guard_next == 0)
      break;
  }
  tw_guard = 0;
}

function tw_recom_tab_detect() {
  let node = document.querySelector("div[data-testid='ScrollSnap-SwipeableList']");
  let targ = tw_deep_child(node, 5);

  return targ && targ.childNodes.length >= 2 && targ.firstChild.innerText == tw_msg("おすすめ") &&
         targ.childNodes[1].style.backgroundColor ? true : false;
}

function tw_filter() {
  let url_changed = (tw_cur_url != location.href);

  if (url_changed) {
    // console.log("tw_filter url changed", tw_cur_url, location.href);
    tw_cur_url = location.href;
    if (tw_is_dark == null)
      tw_is_dark = document.body.style.backgroundColor.indexOf("255") == -1 ? true : false;
      tw_bg_col  = document.body.style.backgroundColor;
  }
  if (tw_is_mobile) {
    let need_init = tw_opt.tw_enabled && tw_opt.tw_fold;
    if (need_init && tw_mob.init != 1)
      tw_mob_init();
//    else if (!need_init && tw_mob.init != -1)
//      tw_mob_uninit();
  }

  if (url_changed)
    tw_set_badge(tw_badge_mode.reset | (tw_opt.tw_enabled ? 0 : tw_badge_mode.disable));

  if (tw_guard == 0) {
    tw_guard = 1;
    tw_is_recom_tab = tw_recom_tab_detect();
    // console.log("tw_is_recom_tab", tw_is_recom_tab);
    tw_filter_core();
    tw_is_recom_tab = false;
  }
  else if (tw_guard_next == 0) {
    tw_guard_next = 1;
  }
}

function tw_keyevent(e) {
  if (!tw_opt.tw_enabled || !tw_opt.tw_shortcut) return true;

  let spell_check = document.activeElement.getAttribute("spellcheck") ? true : false;
  let eated = false;

  if (spell_check) {
//    if (e.keyCode == 13 && e.ctrlKey && tw_opt.tw_shortcut == 2)
//      eated = true;
  }
  else if (!e.ctrlKey && !e.shiftKey && !e.altKey && !e.metaKey) {
    /*
    switch (e.keyCode) { // n, f, r, t, m, u, b, 
    case 0x4e: // 'N' 新しいツイート
    case 0x4d: // 'M' DM作成
    case 0x4C: // 'L' いいね
    case 0x52: // 'R' 返信
    case 0x54: // 'T' リツイート
    case 0x53: // 'S' ツイート共有
    case 0x42: // 'B' ブックマーク
    case 0x55: // 'U' ミュート
    case 0x58: // 'X' ブロック
    //case 0x49: // 'I' メッセージドックの開閉
      eated = true;
      break;
    }
    */
    if (e.keyCode >= 0x41 && e.keyCode <= 0x5A)
      eated = true;
  }

  if (eated) {
    e.stopImmediatePropagation();
    e.preventDefault();
    console.debug("tw_key eated=", eated, e.keyCode, e.ctrlKey, spell_check, document.activeElement);
    return false;
  }
  return true;
}

function tw_main() {
  //console.log("tw_main");
  if (location.href.match(/\b(x|twitter)\.com\/.*/i)) {
    let mo = new MutationObserver(tw_filter);
    mo.observe(document.body, {childList:true, subtree: true});
  }
  if (!document.body.hasAttribute("tw_listener_added")) {
      document.body.addEventListener("keydown", tw_keyevent, false);
      document.body.setAttribute("tw_listener_added", 'true');
  }
}

chrome.runtime.onMessage.addListener(function(req, sender, res) {
  if (req.cmd == "load_done") {
    // console.debug("tw_onMessage(tw_fold): load_done, is_enabled=", req.tw_opt.tw_enabled);
    if (tw_opt.tw_purge_trends != req.tw_opt.tw_purge_trends)
      tw_purge_func = tw_update_purge_func(req.tw_opt.tw_purge_trends);

    tw_opt = req.tw_opt;

    tw_pictlist_set = null;
    if (tw_opt.tw_ext) {
      try {
        let opt = JSON.parse(tw_opt.tw_ext);
        if (opt.pict_list)
          tw_pictlist_set = new Set(opt.pict_list);
      }
      catch(e) {
        console.log("tw_pictlist_set:", e);
      }
    }
    //console.log("tw_pictlist_set:", tw_pictlist_set, tw_opt.tw_ext);

    if (tw_load_cb) {
      let cb = tw_load_cb;
      tw_load_cb = null;
      cb();
    }
  }
  else if (req.cmd == "act") {
//    console.debug("tw_onMessage(tw_fold): act:", req.msg);
    if (req.msg == "onActivated" || req.msg == "onUpdated") {
      tw_load(function() {
      });
    }
  }
  else {
//    console.debug("tw_onMessage(tw_fold): unknown cmd:", msg.cmd);
  }
  return true;
});


//////////////////////////
function tw_mob_listplus(c) {
  let ele = document.createElement("span");
  ele.innerText = tw_foldunset_label;
  ele.style = "padding:10px; color:grey; background-color:transparent; font-weight:bold; font-size:160%;";

  let a = c.querySelector("a[href]");
  if (!a) return;

  ele.onclick = function(e) {
    if (tw_is_firefox) // why?
      history.pushState({foo:"bar"}, "list", location.href);
    location.href = a.href;
  };
  c.firstChild.firstChild.firstChild.firstChild.appendChild(ele);
}

function tw_mob_stat() {
  if (tw_cur_url.slice(-6) == "/lists") {

    let e = document.querySelector(
        "div[aria-label='" + tw_msg("タイムライン: 自分のリスト") + "']");
    if (e && e.firstChild) {
      let mode = 0;
      for (let c of e.firstChild.childNodes) {
        if (c.tw_mob) continue;

        let txt = c.querySelector('div').textContent;
        if (!txt) continue;

        if (mode == 0) {
          if (txt == tw_msg("新しいリストを見つける")) {
            if (c.firstChild.style.display != "none")
              c.firstChild.style.display = "none"; // should not set c.tw_mob;
            mode = 1;
          }
        }
        else if (mode == 1) {
          if (txt == tw_msg("自分のリスト"))
            mode = 2;
          else if (c.firstChild.style.display != "none") {
            c.firstChild.style.display = "none";
            c.tw_mob = 1;
          }
        }
        else if (mode == 2) {
          c.tw_mob = 1;
          if (tw_is_mobile)
            tw_mob_listplus(c);
        }
      }
    }
  }

  if (tw_mob.stat == 1) {
    let n = document.querySelector("div[data-testid='DashButton_ProfileIcon_Link']");
    if (!n) return;

    let d = document.querySelector("div[role='dialog']");
    if (!d) return;

    let a = d.querySelector("a[href]");
    if (!a || a.href.indexOf("/", tw_mob.base_url.length + 1) >= 0) return;

    tw_mob.stat = 2;
    tw_mob.name = a.href.slice(tw_mob.base_url.length);
    n.click();
    location.href = "/" + tw_mob.name + "/lists";
  }
  else if (tw_mob.stat == 2) {
    if (tw_cur_url.slice(-6) == "/lists") {
      let d = document.querySelector("div[aria-roledescription='carousel']");
      if (!d) return;

      let home = tw_mob.base_url + "/home";
      /*tw_mob.lists = [ {url:home, txt:"Home"} ];
      for (let a of d.querySelectorAll("a[href]")) {
        if (a.href.indexOf("/i/lists/") == -1)
          continue;
        tw_mob.lists.push({url: a.href, txt:a.innerText});
      }*/
      tw_mob.stat = 0;
      location.href = home;
    }
  }
}

let tw_mobmenu_id = "tw_mobmenu_id";
function tw_mob_init() {
  //console.debug("tw_mob_init");

  tw_mob.init = 1;
  tw_mob.stat = 0;
  tw_mob.time = 0;
  tw_mob.lists = [
    { url: "https://mobile.twitter.com/home", txt:"home" },
    { url: "https://mobile.x.com/home", txt:"home" },
  ];
  tw_mob.curIdx = 0;
  tw_mob.bgnX = -1;
  tw_mob.endX = -1;
  tw_mob.name = "";
  tw_mob.base_url = tw_cur_url.slice(0, tw_cur_url.indexOf("/", 10)+1);

  let menu = document.querySelector("nav[aria-label='" + tw_msg("メインメニュー") + "']");
  if (!menu)
    return;

  let ele = document.createElement("span");
  ele.innerText = tw_menu_label;
  ele.id = tw_mobmenu_id;
  ele.className = menu.lastChild.className;
  ele.style = "background-color:" + (tw_is_dark ? tw_bg_col : "white") + "; color:grey; font-size:160%; padding-top:5px"
  ele.onclick = function(e) {
    let d = document.querySelector("div[data-testid='DashButton_ProfileIcon_Link']");
    if (d) {
      tw_mob.stat = 1;
      d.click();
    }
    else {
      history.back()
    }
  };

  menu.appendChild(ele);
}

function tw_mob_uninit() {
  if (tw_mob.init != -1) {
    tw_mob.init = -1;
    try {
      let d = $(tw_mobmenu_id);
      if (d)
        d.parentNode.removeChild(d);
    }
    catch(e) {
      console.debug("tw_mob_uninit:", e);
    }
  }
}
//////////////////////////


console.log("tw_filter loaded");

tw_self_lang = document.querySelector("html").getAttribute("lang");
tw_load(null, true);
tw_main();


