# Twitter Stress Reduction

Twitterで消せない「おすすめ」を消すChrome拡張です。<br>

公式ページ: https://shirouzu.jp/tech/twitter-stress-reduction

Chromeウェブストア: https://chrome.google.com/webstore/detail/twitter-stress-reduction/ipnjgahnocpaefhffbnnjonihlihoeic

Firefox ADD-ONs: https://addons.mozilla.org/ja/firefox/addon/twitter-stress-reduction/

おまけ：Manifest v3 対応（＝主にtw_background.jsの修正）するcontributeを期待しつつ…
